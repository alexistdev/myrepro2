package com.alexsander_hendra_wijaya_1811010007.pertemuan12;

public class MahasiswaModelClass {
    Integer id;
    String npm;
    String nama;


    public MahasiswaModelClass(String npm, String nama) {
        this.npm = npm;
        this.nama = nama;
    }

    public MahasiswaModelClass(Integer id, String npm, String nama) {
        this.id = id;
        this.npm = npm;
        this.nama = nama;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getNpm() {
        return npm;
    }

    public void setNpm(String npm) {
        this.npm = npm;
    }

    public String getNama() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }
}
