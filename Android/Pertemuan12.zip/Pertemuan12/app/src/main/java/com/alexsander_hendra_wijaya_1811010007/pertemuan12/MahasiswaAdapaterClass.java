package com.alexsander_hendra_wijaya_1811010007.pertemuan12;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class MahasiswaAdapaterClass extends RecyclerView.Adapter<MahasiswaAdapaterClass.ViewHolder> {

    List<MahasiswaModelClass> mahasiswa;
    Context context;
    DatabaseHelperClass databaseHelperClass;

    public MahasiswaAdapaterClass(List<MahasiswaModelClass> mahasiswa, Context context) {
        this.mahasiswa = mahasiswa;
        this.context = context;
        databaseHelperClass = new DatabaseHelperClass(context);
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View view = layoutInflater.inflate(R.layout.mahasiswa_item_list,parent,false);
        ViewHolder viewHolder = new ViewHolder(view);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        final MahasiswaModelClass mahasiswaModelClass = mahasiswa.get(position);
        holder.tvId.setText("ID :" + Integer.toString(mahasiswaModelClass.getId()));
        holder.tvNpm.setText("NPM :"+ mahasiswaModelClass.getNpm());
        holder.tvNama.setText("NAMA :" + mahasiswaModelClass.getNama());
    }

    @Override
    public int getItemCount() {
        return mahasiswa.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder{
        TextView tvId,tvNpm,tvNama;
        public ViewHolder(@NonNull View itemView){
            super(itemView);
            tvId = itemView.findViewById(R.id.tv_id);
            tvNpm = itemView.findViewById(R.id.tv_NPM);
            tvNama = itemView.findViewById(R.id.tv_NAMA);
        }
    }
}
