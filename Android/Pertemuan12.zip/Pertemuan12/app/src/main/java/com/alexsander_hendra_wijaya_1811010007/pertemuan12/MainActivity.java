package com.alexsander_hendra_wijaya_1811010007.pertemuan12;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    EditText edNpm, edNama;
    Button btnTambah, btnLihat;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        edNpm = findViewById(R.id.editext_npm);
        edNama = findViewById(R.id.editext_nama);

        btnTambah = findViewById(R.id.btn_tambah);
        btnLihat = findViewById(R.id.btn_lihat);

        btnTambah.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String stringNPM = edNpm.getText().toString();
                String stringNama = edNama.getText().toString();

                if(stringNPM.length() <= 0 || stringNama.length() <=0){
                    Toast.makeText(MainActivity.this, "Masukkan semua data",Toast.LENGTH_SHORT).show();
                } else {
                    DatabaseHelperClass databaseHelperClass = new DatabaseHelperClass(MainActivity.this);
                    MahasiswaModelClass mahasiswaModelClass = new MahasiswaModelClass(stringNPM,stringNama);
                    databaseHelperClass.tambahMahasiswa(mahasiswaModelClass);
                    Toast.makeText(MainActivity.this, "Data Mahasiswa berhasil ditambahkan", Toast.LENGTH_SHORT).show();

                    finish();
                    startActivity(getIntent());
                }
            }
        });

        btnLihat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, LihatAcitivity.class);
                startActivity(intent);
            }
        });
    }
}