package com.alexsander_hendra_wijaya_1811010007.pertemuan12;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

public class DatabaseHelperClass extends SQLiteOpenHelper {

    //Database Version
    private static final int DATABASE_VERSION = 1;
    //Database Name
    private static final String DATABASE_NAME = "dbmahasiswa";
    //Database Tabel
    private static final String TABLE_NAME = "tbmahasiswa";
    //Table Columns
    private static final String ID = "id";
    private static final String NPM = "npm";
    private static final String NAMA = "nama";
    private SQLiteDatabase sqLiteDatabase;

    //QUERY

    private final String CREATE_TABLE = "CREATE TABLE " +
            TABLE_NAME + "(" +
            ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
            NPM + " TEXT, " +
            NAMA + " TEXT" +
            ")";

    //constructor
    public DatabaseHelperClass (Context context){
        super(context,DATABASE_NAME,null,DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1) {
        db.execSQL(" DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(db);
    }

    //tambah data mahasiswa
    public void tambahMahasiswa(MahasiswaModelClass mahasiswaModelClass){
        ContentValues contentValues = new ContentValues();
        contentValues.put(DatabaseHelperClass.NPM, mahasiswaModelClass.getNpm());
        contentValues.put(DatabaseHelperClass.NAMA, mahasiswaModelClass.getNama());
        sqLiteDatabase = this.getWritableDatabase();
        sqLiteDatabase.insert(DatabaseHelperClass.TABLE_NAME,null,contentValues);
    }

    public List<MahasiswaModelClass> getMahasiswaList(){
        String sql = "SELECT * FROM " + TABLE_NAME;
        sqLiteDatabase = this.getReadableDatabase();
        List<MahasiswaModelClass> simpanMahasiswa = new ArrayList<>();
        Cursor cursor = sqLiteDatabase.rawQuery(sql,null);
        if(cursor.moveToFirst()){
            do{
                int id = Integer.parseInt(cursor.getString(0));
                 String npm = cursor.getString(1);
                String nama = cursor.getString(2);
                simpanMahasiswa.add(new MahasiswaModelClass(id,npm,nama));
            }while(cursor.moveToNext());
        }
        cursor.close();
        return simpanMahasiswa;
    }


}
