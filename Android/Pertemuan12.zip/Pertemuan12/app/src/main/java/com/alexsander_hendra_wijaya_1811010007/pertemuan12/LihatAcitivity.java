package com.alexsander_hendra_wijaya_1811010007.pertemuan12;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.widget.Toast;

import java.util.List;

public class LihatAcitivity extends AppCompatActivity {
    RecyclerView recyclerView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lihat_acitivity);

        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setHasFixedSize(true);

        DatabaseHelperClass databaseHelperClass = new DatabaseHelperClass(this);
        List<MahasiswaModelClass> mahasiswaModelClasses = databaseHelperClass.getMahasiswaList();

        if(mahasiswaModelClasses.size() > 0){
            MahasiswaAdapaterClass mahasiswaAdapaterClass = new MahasiswaAdapaterClass(mahasiswaModelClasses,LihatAcitivity.this);
            recyclerView.setAdapter(mahasiswaAdapaterClass);
        } else {
            Toast.makeText(this, "Data kosong", Toast.LENGTH_SHORT).show();
        }
    }
}